=======
Credits
=======

Author
------

* Simon Percivall <percivall@gmail.com>

Contributors
------------

* Derived from an implementation by Raymond Hettinger
* Set operations from ``abcoll.py`` in Python core.
